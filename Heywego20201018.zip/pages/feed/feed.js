var mqtt = require('../../utils/mqtt.min.js') //根据自己存放的路径修改
const crypto = require('../../utils/hex_hmac_sha1.js'); //根据自己存放的路径修改
//const { time } = require('console');

const app = getApp()
const myDate = new Date()
Page({
data: {
  Switch:'',
  BtnStat:'开门',
num:1,
num_cur:0,
Temp:0,
time:0,
weight:0,
minusStatus:'disable',
currentTime:0,
client:{}
},

onLoad: function () {
  //this.doConnect()
  
  this.doInit()
  this.getWeight()
  this.setData({
    currentTime:myDate.getHours()
  })
},

onUnLoad: function () {
  this.mqtt.disConnected()
},
feedNow:function (sb) {
  var dat;
  //console.log(this.data.BtnStat)
  if(sb)
  {
    dat="openit";
  }
  else
  {
    dat="closit"
  }
  //console.log(dat)
  wx.request({
    url: 'https://api.heclouds.com/cmds?device_id=694151576',
    method:"POST",
    header:{
      "api-key":"Knj2mh2Jr=MqFTgHvXqeJmacYQE="
    },
    data:dat,
    success(res)
    {
      console.log(res);
    }
  })
},
//按钮点击事件
addfood:function () {
  var dat;
  console.log(this.data.BtnStat)
  wx.showLoading({
    title: '数据传输中',
    mask:true
  })
  if(this.data.BtnStat==="关门")
  dat="closit";
  else
  dat="openit"
  console.log(dat)
  wx.request({
    url: 'https://api.heclouds.com/cmds?device_id=694151576',
    method:"POST",
    header:{
      "api-key":"Knj2mh2Jr=MqFTgHvXqeJmacYQE="
    },
    data:dat,
    success(res)
    {
      console.log(res);
      wx.hideLoading({
        success: (res) => {
          wx.showToast({
            title: '传输完成',
            mask:true,
            duration:2000
          })
        },
      })
    }
  })
},
feed()
{
  var that =this;
  console.log("设置喂食成功！")
  console.log("当前剩余食物："+that.data.weight)
  //食物剩余量的判断
  if(that.data.weight*1000<50)
  {
    console.log("食物不足一份，请添加食物！")
    wx.showToast({
      title:"请添加食物！",
     
      duration:2000
    })
  }
  if(that.data.weight*1000<that.data.num*50)
  {
    wx.showToast({
      title:"请减少份数！",
      duration:2000
    })
    console.log("请减少份数！")
  }else{
    //console.log("设置的份数"+that.data.num)
   // console.log("设置的开始投喂时间"+that.data.time)
    if(that.data.time==that.data.currentTime)
    {
      console.log("可以开始投喂！")
      wx.showToast({
        title:"可以开始投喂！",
        icon:'success',
        duration:2000
      })
      var num_cur=0;
      //下发，投喂次数的命令！
      console.log("num is :"+that.data.num)
      setTimeout(function()
      {
        that.data.num_cur=0;
        that.feedAuto();
      },3000)
    }
  }
},
feedAuto:function()
{
  var that =this;
  this.data.num_cur++;
  console.log("Fuck it! num="+that.data.num+"num_cur"+that.data.num_cur)
  that.feedNow(true)
  if(that.data.num>that.data.num_cur)
  {
    setTimeout(function(){
      that.feedAuto()
    },3000)
  }
  else
  {
    wx.showToast({
      title: '自动操作完成',
      duration:1000,
      mask:true
    })
  }
},
getTime:function(e)
{
//  console.log("time :"+myDate.getHours());
  this.setData({
    currentTime:myDate.getHours(),
    time:e.detail.value
  })
},
//事件处理函数
/*点击减号*/
bindMinus: function() {
var num = this.data.num;
if (num>1) {
num--;
}
var minusStatus = num>1 ? 'normal':'disable';
this.setData({
num:num,
minusStatus:minusStatus
})
},
/*点击加号*/
bindPlus: function() {
var num = this.data.num;
num++;
var minusStatus = num > 1 ? 'normal' : 'disable';
this.setData({
num:num,
minusStatus: minusStatus
})
},
/*输入框事件*/
bindManual: function(e) {
var num = e.detail.value;
var minusStatus = num > 1 ? 'normal' : 'disable';
this.setData({
num:num,
minusStatus: minusStatus
})
},
get_num()
{
  console.log(this.data.num);
},
doInit(){
  var that=this;
  wx.request({
    url: "https://api.heclouds.com/devices/694151576/datastreams?datastream_ids=switch",
    header: {
      'content-type': 'application/x-www-form-urlencoded',
      "api-key": "Knj2mh2Jr=MqFTgHvXqeJmacYQE="
    },
    data: {

    },
    success(res) {
      res.data.data.forEach(element => {
        switch(element.id)
        {
          case "switch":
            that.setData({Switch:element.current_value==1?"开":"关"});
            that.setData({BtnStat:element.current_value==1?"关门":"开门"});
          break;
        }
        console.log("read onenet suc");
        //that.get_num();
      });

    },
    fail(res) {
      console.log("请求失败")
      deviceConnected = false
    }
  })
},
getWeight(){
  var that=this;
  wx.request({
    url: "https://api.heclouds.com/devices/694151576/datastreams?datastream_id=weight",
    header: {
      'content-type': 'application/x-www-form-urlencoded',
      "api-key": "Knj2mh2Jr=MqFTgHvXqeJmacYQE="
    },
    data: {

    },
    success(res) {
      res.data.data.forEach(element => {
        switch(element.id)
        {
         
          case "weight":
            that.setData({weight:element.current_value});
          break;
        }
        console.log("read onenet suc")
      });

    },
    fail(res) {
      console.log("请求失败")
      deviceConnected = false
    }
  })
  
},
//doConnect函数（后来添加的）
doConnect(){

  var that=this

  const deviceConfig = {
    productKey: "a1RIvAXG2JN",
    deviceName: "miniprogram",
    deviceSecret: "07a026b1169966e3be12e4e5450d4b34",
    regionId: "cn-shanghai"
  };
  const options = this.initMqttOptions(deviceConfig);
  console.log(options)
  //替换productKey为你自己的产品的（注意这里是wxs，不是wss，否则你可能会碰到ws不是构造函数的错误）
  const client = mqtt.connect('wxs://a1RIvAXG2JN.iot-as-mqtt.cn-shanghai.aliyuncs.com',options)
  client.on('connect', function () {
    console.log('连接服务器成功')
    //订阅主题，替换productKey和deviceName(这里的主题可能会不一样，具体请查看后台设备Topic列表或使用自定义主题)
    client.subscribe('/a1RIvAXG2JN/miniprogram/user/data_get', function (err) {
      if (!err) {
         console.log('订阅成功！');
      }
    })
    client.publish('/a1RIvAXG2JN/miniprogram/user/feeding', '喂食界面已连接',function (err) {
      if (!err) {
         console.log('发布成功！');
      }
    })
  }
  
  
  
  )
//接收消息监听
  client.on('message', function (topic, message) {
    // message is Buffer
    console.log('收到消息：'+message.toString())
    client.end()//关闭连接 
  })
},
//IoT平台mqtt连接参数初始化
initMqttOptions(deviceConfig) {

  const params = {
    productKey: deviceConfig.productKey,
    deviceName: deviceConfig.deviceName,
    timestamp: Date.now(),
    clientId: Math.random().toString(36).substr(2),
  }
  //CONNECT参数
  const options = {
    keepalive: 60, //60s
    clean: true, //cleanSession不保持持久会话
    protocolVersion: 4 //MQTT v3.1.1
  }
  //1.生成clientId，username，password
  options.password = this.signHmacSha1(params, deviceConfig.deviceSecret);
  options.clientId = `${params.clientId}|securemode=2,signmethod=hmacsha1,timestamp=${params.timestamp}|`;
  options.username = `${params.deviceName}&${params.productKey}`;

  return options;
},

/*
生成基于HmacSha1的password
参考文档：https://help.aliyun.com/document_detail/73742.html?#h2-url-1
*/
signHmacSha1(params, deviceSecret) {

  let keys = Object.keys(params).sort();
  // 按字典序排序
  keys = keys.sort();
  const list = [];
  keys.map((key) => {
    list.push(`${key}${params[key]}`);
  });
  const contentStr = list.join('');
  return crypto.hex_hmac_sha1(deviceSecret, contentStr);
}

})