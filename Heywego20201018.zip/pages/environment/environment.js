//logs.js
var mqtt = require('../../utils/mqtt.min.js') //根据自己存放的路径修改
const crypto = require('../../utils/hex_hmac_sha1.js'); //根据自己存放的路径修改
var amapFile = require('../../utils/amap-wx.js');//天气预报引用的js文件

Page({

  /**
   * 页面的初始数据
   */
  
  data: {
    weather: {},
    Temp: 0,
    humity: 0,
    weight: 0,
    Light:300,
    isShow:0
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    //this.doConnect()
    var that =this;
    var myAmapFun = new amapFile.AMapWX({ key: 'd2ea62253af12470f0ce5411889573a6' });//高德地图密钥

    myAmapFun.getWeather({
      success: function (data) {
        that.setData({
          weather: data
        });
      },
      fail: function (info) {
        // wx.showModal({title:info.errMsg})
      }
    })//获取天气信息



    if(that.data.humity>50&&that.data.humity>25)
    {
      that.data.isShow=1;
    }
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.test1();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

  //doConnect函数（后来添加的）
  doConnect() {

    var that = this

    const deviceConfig = {
      productKey: "a1RIvAXG2JN",
      deviceName: "miniprogram",
      deviceSecret: "07a026b1169966e3be12e4e5450d4b34",
      regionId: "cn-shanghai"
    };
    const options = this.initMqttOptions(deviceConfig);
    console.log(options)
    //替换productKey为你自己的产品的（注意这里是wxs，不是wss，否则你可能会碰到ws不是构造函数的错误）
    const client = mqtt.connect('wxs://a1RIvAXG2JN.iot-as-mqtt.cn-shanghai.aliyuncs.com', options)
    client.on('connect', function () {
      console.log('连接服务器成功')
      //订阅主题，替换productKey和deviceName(这里的主题可能会不一样，具体请查看后台设备Topic列表或使用自定义主题)
      client.subscribe('/a1RIvAXG2JN/miniprogram/user/data_get', function (err) {
        if (!err) {
          console.log('订阅成功！');
        }
      })
      client.publish('/a1RIvAXG2JN/miniprogram/user/feeding', ' 环境界面已连接', function (err) {
        if (!err) {
          console.log('发布成功！');
        }
      })
    })
    //接收消息监听
    client.on('message', function (topic, message) {
      // message is Buffer
      //var Data=message.toString();
      //message = message.replace(/\ufeff/g, "");
      //var jsonObj = JSON.parse('{"Temp":"37.5","Hum":"70","Light":"50"}');
      //that.setData([jsonObj]);
      let dataFromDev = {}
      //dataFromDev=JSON.parse('message.toString()')
      console.log(message)
      console.log('收到消息：' + message.toString())
      client.end() //关闭连接 
    })


  },
  //IoT平台mqtt连接参数初始化
  initMqttOptions(deviceConfig) {

    const params = {
      productKey: deviceConfig.productKey,
      deviceName: deviceConfig.deviceName,
      timestamp: Date.now(),
      clientId: Math.random().toString(36).substr(2),
    }
    //CONNECT参数
    const options = {
      keepalive: 60, //60s
      clean: true, //cleanSession不保持持久会话
      protocolVersion: 4 //MQTT v3.1.1
    }
    //1.生成clientId，username，password
    options.password = this.signHmacSha1(params, deviceConfig.deviceSecret);
    options.clientId = `${params.clientId}|securemode=2,signmethod=hmacsha1,timestamp=${params.timestamp}|`;
    options.username = `${params.deviceName}&${params.productKey}`;

    return options;
  },

  /*
  生成基于HmacSha1的password
  参考文档：https://help.aliyun.com/document_detail/73742.html?#h2-url-1
  */
  signHmacSha1(params, deviceSecret) {

    let keys = Object.keys(params).sort();
    // 按字典序排序
    keys = keys.sort();
    const list = [];
    keys.map((key) => {
      list.push(`${key}${params[key]}`);
    });
    const contentStr = list.join('');
    return crypto.hex_hmac_sha1(deviceSecret, contentStr);
  },
  test1:  function () {
    var that=this;
    wx.request({
      url: "https://api.heclouds.com/devices/694151576/datastreams?datastream_ids=temperature,humidity,weight",
      header: {
        'content-type': 'application/x-www-form-urlencoded',
        "api-key": "Knj2mh2Jr=MqFTgHvXqeJmacYQE="
      },
      data: {

      },
      success(res) {
        res.data.data.forEach(element => {
          switch(element.id)
          {
            case "temperature":
              that.setData({Temp:element.current_value});
            break;
            case "humidity":
              that.setData({humity:element.current_value});
            break;
            case "weight":
              that.setData({weight:element.current_value});
            break;
          }
          console.log("read onenet suc")
        });

      },
      fail(res) {
        console.log("请求失败")
        deviceConnected = false
      }
    })

  }
})