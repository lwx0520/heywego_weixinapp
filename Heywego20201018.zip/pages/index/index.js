var amapFile = require('../../utils/amap-wx.js');

Page({
  data: {
    weather: {},
  },
  onLoad: function () {
    var that = this;
    var myAmapFun = new amapFile.AMapWX({ key: 'd2ea62253af12470f0ce5411889573a6' });


    myAmapFun.getWeather({
      success: function (data) {
        that.setData({
          weather: data
        });
      },
      fail: function (info) {
        // wx.showModal({title:info.errMsg})
      }
    })
  }
})